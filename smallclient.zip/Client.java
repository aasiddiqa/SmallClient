import java.util.Scanner;

public class Client {
	public static void main(String[] args) throws Exception {
		
		//String[] inputFiles = { "/home/ash/tigerdata/", "edges.csv", "edges_schema.csv" }; //srcDirectory, FileName, FileSchema
		String[] inputFiles = { "/media/ash/My Passport/Dataset/", "1.csv", "1_schema.csv" }; //srcDirectory, FileName, FileSchema
		String[] indexAttr = {"IF1", "IF2", "IF3", "IF4", "IF5"};
		String dstDir = "/terabyte/";//destDirectory
		//String queryString = "SELECT linearid FROM primaryroads.csv WHERE linearid = 1104468668654 ;";
		String queryString = "SELECT * FROM 1.csv WHERE IF3 = 350 ;";
		Shell sh = new Shell();
		//shell2 sh2 = new shell2();
		
		//sh.runUpload(inputFiles, dstDir);
		//sh.runIndex(inputFiles, indexAttr, dstDir);
		//sh.runQuery(queryString, dstDir);
		
		//sh.runQuery(getQueryString(), dstDir);
		sh.runPredictor(inputFiles, dstDir);
	}
	public static String getQueryString() {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Query:");
		return(s.nextLine());
	}
}
