import java.util.*;


public class Predictor {
	//static ArrayList<ArrayList<String>> tSlots = new ArrayList<ArrayList<String>>();
	//ArrayList<String> Queries = new ArrayList<String>();

	public String decide(String attr, int numSlots, ArrayList<ArrayList<String>> tSlots){
		//String iStatus = getStatus(attr);//indexed/non-indexed
		float avgR = getAvgR(getAR(attr, numSlots, tSlots));// get access rate and average
		float rem = (float) 0.04;
		float crt = (float) 0.05;
		if (getStatus(attr).equals("indexed")){
			if (avgR<rem)
				//System.out.println("Remove");
				return "Remove";
			else
				//System.out.println("Sustain");
				return "Sustain";
		}			
		if (getStatus(attr).equals("nonindexed")){
			if (avgR>crt)
				//System.out.println("Create");
				return "Create";
			else
				//System.out.println("Sustain");
				return "Sustain";
		}
		return null;
	}
	public static float getAvgR(ArrayList<Float> AR){
		float sum = 0;
		for (float ar: AR){
			sum+=ar;
		}
		//System.out.println("Average is " + sum/AR.size());
		return sum/AR.size();
	}
	public static ArrayList<Float> getAR(String attr, int numSlots, ArrayList<ArrayList<String>> tSlots){
		int dOccur[] = new int [numSlots];//occurance count in each time slot
		ArrayList<Float> AR = new ArrayList<Float>();
		for (int q = 0; q<numSlots; q++){//queries in each time Slot
			dOccur[q]=0;
			for (int s = 0; s< tSlots.get(q).size(); s++){//attribute in each query in a time slot
				if (attr.equals(tSlots.get(q).get(s)))
					dOccur[q]=dOccur[q]+1;
			}
			//System.out.println("Occurance of "+ attr +" is "+dOccur[q]);
			//System.out.println("Total Queries in T["+ q +"] are " +tSlots.get(q).size());
			AR.add((float) dOccur[q]/tSlots.get(q).size());
			//System.out.println("AR["+ q +"] is " +AR.get(q));
		}
		return AR;
	}
	public static String getStatus(String attr){
		String status="nonindexed";
		for(String i:getIAtrr()){
			if(attr.equals(i))
				status="indexed";
		}
		return status;
	}
	public static ArrayList<ArrayList<String>> getSlots(int numSlots, String[] inputFiles, String dstDir){
		ArrayList<ArrayList<String>> tSlots = new ArrayList<ArrayList<String>>();
		for (int i = 0; i<numSlots; i++){
			tSlots.add(new ArrayList<String>());
		}
		tSlots.get(0).add("id");
		tSlots.get(0).add("id");
		tSlots.get(0).add("gender");
		tSlots.get(0).add("address");
		tSlots.get(1).add("id");
		tSlots.get(1).add("id");
		tSlots.get(1).add("name");
		tSlots.get(1).add("name");
		tSlots.get(1).add("address");
		tSlots.get(2).add("id");
		tSlots.get(2).add("id");
		tSlots.get(2).add("name");
		tSlots.get(2).add("address");
		tSlots.get(3).add("gender");
		tSlots.get(3).add("address");
		tSlots.get(3).add("id");
		tSlots.get(3).add("id");
		tSlots.get(3).add("name");
		tSlots.get(4).add("address");
		tSlots.get(4).add("gender");
		tSlots.get(4).add("address");
		tSlots.get(4).add("address");
		tSlots.get(5).add("gender");
		tSlots.get(5).add("address");
		tSlots.get(6).add("id");
		tSlots.get(6).add("id");
		tSlots.get(6).add("name");
		tSlots.get(6).add("name");
		tSlots.get(6).add("address");
		tSlots.get(7).add("id");
		tSlots.get(7).add("name");
		tSlots.get(7).add("address");
		tSlots.get(8).add("gender");
		tSlots.get(8).add("address");
		tSlots.get(8).add("address");
		tSlots.get(9).add("gender");
		tSlots.get(9).add("address");
		tSlots.get(9).add("id");
		tSlots.get(9).add("id");
		return tSlots;
	}
	public String[] getDAttr(String[] inputFiles, String dstDir){
		String dAttr[] = {"id","name","address","gender"};
		return dAttr;
	}
	public static String[] getIAtrr(){
		String iAttr[] = {"id","gender"};
		return iAttr;
	}
}
