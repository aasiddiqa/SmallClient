import java.io.IOException;
import java.util.Arrays;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.BlockLocation;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;


public class BlockInfo {
	
	public BlockLocation[] getBlkLocations(String dst) throws IOException {
		
		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));
		
		FileSystem fs = FileSystem.get(conf);
		
		Path path = new Path(fs.getWorkingDirectory() + dst);
		
		//DistributedFileSystem hdfs = (DistributedFileSystem) fs;
		FileStatus status = fs.getFileStatus(path);

		return fs.getFileBlockLocations(status, 0, status.getLen());
	}
	
	public void printBlockInf(BlockLocation[] locs) throws IOException {
		System.out.println("\nNumber of Blocks : " + locs.length);
		int i =0;
		while (i < locs.length) {
			System.out.println("\nInformation of Block : " + i);
			//System.out.println("\nBlockLocations: " + locs[i]);
			System.out.println("BlockHostNames: " + Arrays.toString(locs[i].getNames()));//[127.0.0.1:50010]
			System.out.println("BlockHosts: " + Arrays.toString(locs[i].getHosts()));
			System.out.println("Offset: " + locs[i].getOffset());
			System.out.println("Size: " + locs[i].getLength());
			System.out.println("Topology path: " + Arrays.toString(locs[i].getTopologyPaths()));//[/default-rack/127.0.0.1:50010]
			
			i ++;
		}
	}
	
	public void readBlock(Path path, int position, int length) throws IOException {
		System.out.println("Accessing Block");
		
		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));
		
		FileSystem fs = FileSystem.get(conf);
		
		if (!fs.exists(path)) {
			System.out.println("File does not exists");
			return;
		}

		FSDataInputStream in = fs.open(path);
		
		int offset = 0;
		byte[] buffer = new byte[length];
		
		in.read(position, buffer, offset, length);
		System.out.write(buffer);
		System.out.println("\nSuccess");
	}
	
	@SuppressWarnings("deprecation")
	public void readRecords(Path path, int position, int length) throws IOException {
		System.out.println("Accessing records");
		
		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));
		
		FileSystem fs = FileSystem.get(conf);
		
		if (!fs.exists(path)) {
			System.out.println("File does not exists");
			return;
		}

		FSDataInputStream in = fs.open(path);
		String record;
		while ((record = in.readLine()) != null) {
			System.out.println("Record : " + record);
		}
		
		System.out.println("\nSuccess");
	}
}
