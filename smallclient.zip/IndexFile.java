import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.Arrays;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.BlockLocation;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

/*
 * storeIndex class stores the provided BTree object as a file permanently in indexes directory.
 * getIndex method returns the BTree object and displyIndex method call the toString method of 
 * strBTreeList class to traverse whole BTree
 */
public class IndexFile {

	public Boolean store(String filePath, BTree index, String indexName) throws IOException{
		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));

		FileSystem fs = FileSystem.get(conf);
		Path path = new Path(fs.getWorkingDirectory() + filePath);

		if (!fs.exists(path)) {
			OutputStream out = fs.create(path, (short) 1);
			ObjectOutputStream obj = null;
			try
			{			
				obj = new ObjectOutputStream(out);
				obj.writeObject(index);
				obj.flush();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally{
				try{
					if(obj != null) obj.close();
				} catch (Exception ex){
				}
			}
			return true;
		}
		else {
			//System.out.println("Unable to store index:"+ indexName +" Already exist");
			return false;
		}
	}

	public BlockLocation[] storeReplica(String filePath, BTree index, String hostName) throws IOException{
		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));

		FileSystem fs = FileSystem.get(conf);

		Path path = new Path(fs.getWorkingDirectory() + filePath);

		OutputStream out = fs.create(path, (short) 1);
		ObjectOutputStream obj = null;
		//Boolean success = false;
		try
		{			
			obj = new ObjectOutputStream(out);
			obj.writeObject(index);
			obj.flush();
			
			//success = true;
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally{
			try{
				if(obj != null) obj.close();
			} catch (Exception ex){
			}
		}
		
		BlockInfo inf = new BlockInfo();
		BlockLocation[] idxlocs = inf.getBlkLocations(filePath);
		
		//store all blocks of each index on location same as DataBlock's location
		for (int i = 0; i < idxlocs.length; i ++) {
			//System.out.println("Index Block PreLocation " +Arrays.toString(idxlocs[i].getNames()));
			
			String[] hosts = new String[1];
			hosts[0] = hostName;
			idxlocs[i].setHosts(hosts);
			
			System.out.println("Updated Index Block Location " +Arrays.toString(idxlocs[i].getHosts()));
			System.out.println("Updated Index Block Location " +Arrays.toString(idxlocs[i].getNames()));
		}
		
		return idxlocs;
	}
	public void print(String indexLoc) throws IOException{
		
		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));

		FileSystem fs = FileSystem.get(conf);

		Path path = new Path(fs.getWorkingDirectory() + indexLoc);
		
		if(!fs.exists(path)) {
			System.out.println("Index not found at " +path);
			return;
		}
		
		FSDataInputStream in = null;
		ObjectInputStream obj = null;
		BTree index = new BTree();
		try {
			in = fs.open(path);
			obj = new ObjectInputStream(in);
			//indexMetadata data = (indexMetadata) objIs.readObject();
			index = (BTree) obj.readObject();
			System.out.println("Retrieved Index is: \n"+index.toString());
			System.out.println("Path is " + path);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				if(obj != null) obj.close();
			} catch (Exception ex){
			}
		}
		
	}
	
	public static BTree get(String indexLoc) throws IOException {
		
		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));

		FileSystem fs = FileSystem.get(conf);

		Path path = new Path(fs.getWorkingDirectory() + indexLoc);
		
		FSDataInputStream in = null;
		ObjectInputStream obj = null;
		BTree index = new BTree();
		try {
			in = fs.open(path);
			obj = new ObjectInputStream(in);
			//indexMetadata data = (indexMetadata) objIs.readObject();
			index = (BTree) obj.readObject();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				if(obj != null) obj.close();
			} catch (Exception ex){
			}
		}	return index;
	}
	
}