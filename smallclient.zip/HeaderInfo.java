import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;


public class HeaderInfo {
	public String[] indexAttrList;
	ArrayList<Integer> tmpAttrNum = new ArrayList<Integer>();
	ArrayList<String> tmpAttrList = new ArrayList<String>();
	
	public void analyzeIndexAttr(String fileDir, String fileName, String schema, String[] attrList) throws Exception{
		String name[] = fileName.split("\\.");
		int[] attrNum = getSubscript(fileDir + schema, attrList);
		
/**
 * remove unmatched attributes
 **/
		//sArrayList<String> tmpAttrList = new ArrayList<String>();
		for (int i = 0; i < attrNum.length; i ++) {
			if(attrNum[i] != -1){
/**
 * check if indexes already exist
**/
				Configuration conf = new Configuration();
				conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
				conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
				conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));
				FileSystem fs = FileSystem.get(conf);
				//System.out.println(fileDir + "indexes"+ name[0] +"/" + attrList[i]);
				Path idxPath = new Path(fs.getWorkingDirectory() + fileDir + "indexes"+ name[0] +"/" + attrList[i]);
				if (!fs.exists(idxPath)) {
					//System.out.println("Indexes found in dir");
					tmpAttrNum.add(attrNum[i]);
					tmpAttrList.add(attrList[i]);
				}
			}
		}
/**
 * update list
 **/
		indexAttrList = tmpAttrList.toArray(new String[tmpAttrList.size()]);
	}
	
	@SuppressWarnings("deprecation")
	public static int[] getSubscript(String file, String[] attrName) throws Exception {
		
		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));

		FileSystem fs = FileSystem.get(conf);

		Path path = new Path(fs.getWorkingDirectory() + file);
		
		FSDataInputStream in = fs.open(path);
		
		//header is stored as cell[]
		String cell[] = in.readLine().split(",");
		
		int[] Subscript = new int[attrName.length];
		for (int i = 0; i < attrName.length; i ++){
			Subscript[i] = -1;
			for (int c = 0;c < cell.length; c ++) {
				if (cell[c].equalsIgnoreCase(attrName[i]))
					Subscript[i] = c;
			}
		}
		return(Subscript);
	}
	
	public static int getSubscript(String file, String attrName) throws Exception {
		
		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));

		FileSystem fs = FileSystem.get(conf);

		Path path = new Path(fs.getWorkingDirectory() + file);
		
		FSDataInputStream in = fs.open(path);
		
		//header is stored as cell[]
		String cell[] = in.readLine().split(",");
		int Subscript = -1;
		for (int c = 0;c < cell.length; c ++) {
			if (cell[c].equalsIgnoreCase(attrName))
				Subscript = c;
		}
		return(Subscript);
	}

}
