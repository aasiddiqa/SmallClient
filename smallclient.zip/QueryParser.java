import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;

import org.apache.commons.lang.time.StopWatch;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;


public class QueryParser {
	public String fileName;
	public ArrayList<String> selData = new ArrayList<String>();//columns to be retrieved
	public ArrayList<String> attrName = new ArrayList<String>();//column to be used as selection predicate
	public ArrayList<String> attrValue = new ArrayList<String>();//value to be matched for searching
	public ArrayList<String> multiAttr = new ArrayList<String>();//query may have more than one selection predicates
	public ArrayList<Integer> dataIndexes = new ArrayList<Integer>();//subscripts of selData
	
	public String analyze(String query, String fileDir){
		//StopWatch stopwatch = new StopWatch();
		//stopwatch.start();
		
		try {
			String[] words = query.split(" ");
			int i = 0;
			if(! words[i].equals("SELECT")) {//query is starting from SELECT
				System.out.println("Syntax Error: Query should start from keyword 'SELECT'");
				return "null";
			}
			i ++;
			if(i >= words.length) {
				System.out.println("Incomplete Query: SELECT query must specify data and SourceFileName after FROM");
				return "null";
			}
//collect selData
			//System.out.println("Next word is " +words[i]+ " and i is " +i);
			while(i < words.length && !words[i].equals("FROM")){ //selection attributes are collected as selData
				selData.add(words[i]);
				i ++;
			}
			if (i >= words.length || !words[i].equals("FROM")) {
				System.out.println("Incomplete Query: 'FROM' clause required");
				return "null";
			}
			i ++;
			//System.out.println("Next word is " +words[i]+ " and i is " +i);
			if (i >= words.length) {
				System.out.println("Incomplete Query: 'FROM' clause undefined");
				return "null";
			}
//collect fileName
			//System.out.println("fileName is " + words[i]);
			fileName = words[i];
//verify fileName
			if (!verifyFileName(fileDir+ fileName)) {
				System.out.println("Source FileName is incorrect");
				return "null";
			}
//verfiy selData
			//System.out.println("fileName is " + fileName);
			String[] Name = fileName.split("\\.");
			//System.out.println(Name);
			//System.out.println(Name[0]);
			if(!verifyData(fileDir+ Name[0] + "_schema.csv", selData)) {
				System.out.println("Selection data is incorrect");
				return "null";
			}
//collect <key,val>
			i ++;
			if(i >= words.length || !words[i].equals("WHERE")) {//query must have WHERE clause
				System.out.println("Incomplete Query: 'WHERE' clause required");
				return "null";
			}
			i ++;
			if(i >= words.length){
				System.out.println("Incomplete Query: 'WHERE' clause undefined");
				return "null";
			}
			while(i < words.length){ 
//collect selection predicate(s): keys
				attrName.add(words[i]);
				i ++;
				if(i >= words.length || !words[i].equals("=")) {
					System.out.println("Incomplete Query: 'WHERE' clause undefined");
					return "null";
				}
				i ++;
				if(i >= words.length) {
					System.out.println("Incomplete Query: 'WHERE' clause undefined");
					return "null";
				}
//collect selection values
				attrValue.add(words[i]);
				i ++;
//collect multiAttr
				if(i < words.length && !words[i].equals(";")) {
					if (words[i].equals("AND") || words[i].equals("OR")) {
						multiAttr.add(words[i]);
					}
					else {
						System.out.println("Syntax Error:'" + words[i] + "' is undefined");
						return "null";
					}
				}
				i++;
			}
			//System.out.println("Index attr are "+ attrName.toString());
//verify indexes
			//String name[] = fileName.split("\\.");
			//if (!verifyIndex(fileDir + "metadata"+ name[0] +"/", attrName)) {
			if (!verifyIndex(fileDir + "metadata/", attrName)) {
				return "noIndex";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		//stopwatch.suspend();
		//System.out.println("Query Analyzing Time " +stopwatch);
		return "hasIndex";
	}
	
	public Boolean verifyFileName(String fileName) throws IOException{
		Boolean success = false;
		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));
		
		FileSystem fs = FileSystem.get(conf);
		
		Path path = new Path(fs.getWorkingDirectory() + fileName);
		if(fs.exists(path))
			success = true;
		return success;
	}
	
	public Boolean verifyData(String fileName, ArrayList<String> selData) throws Exception{
//for whole row
		if (selData.get(0).equals("*")) {
			dataIndexes.add(-1);
			return(true);
		}
//for specified columns
		else {
			for(int i = 0; i < selData.size(); i ++) {
				int num = HeaderInfo.getSubscript(fileName, selData.get(i));
				if (num ==-1)
					return false;
				dataIndexes.add(num);	
			}
			return true;
		}
	}
	public Boolean verifyIndex(String fileDir, ArrayList<String> indexName) throws IOException {
		
		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));
		
		FileSystem fs = FileSystem.get(conf);
		
		for (int i =0; i<indexName.size(); i ++) {
			Path path = new Path(fs.getWorkingDirectory() + fileDir + indexName.get(i) + ".ser");
			//System.out.println(path);
			if (!fs.exists(path))
				return false;
		}
		return true;
	}
	
	
}
