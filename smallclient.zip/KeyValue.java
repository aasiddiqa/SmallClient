import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.BlockLocation;

public class KeyValue {

	ArrayList<ArrayList<String>> keys = new ArrayList<ArrayList<String>>();
	ArrayList<String> key = new ArrayList<String>();
	ArrayList<Integer> values = new ArrayList<Integer>();
	

	public ArrayList<BTree> setkeyval(String filePath, BlockLocation loc,
			ArrayList<Integer> attrNums)
			throws Exception {
/**
 * create index trees according to No. of indexAttr
 * create keys for each indexAttr
**/
		ArrayList<BTree> strbTree = new ArrayList<BTree>();
		for (int c = 0; c < attrNums.size(); c++) {
			strbTree.add(new BTree());
		}

		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));
		
		FileSystem fs = FileSystem.get(conf);
		Path path = new Path(fs.getWorkingDirectory() + filePath);
		
		if(!fs.exists(path)) {
			System.out.println("Error: Block at " +path+ " does not exist");
			//return 0;
		}
		else {
/**
 * reading whole block in buffer first
**/			
			FSDataInputStream fin = fs.open(path);
			byte[] buffer = new byte[(int) loc.getLength()];//block size
			fin.read(loc.getOffset(), buffer, 0, (int) loc.getLength());//access a block
/**
 * converting byte[] buffer into InputStream reading each line to get
 * key,val and add <key,val> into index tree
**/
			InputStream in = null;
			BufferedReader br = null;
			try {
				in = new ByteArrayInputStream(buffer);
				br = new BufferedReader(new InputStreamReader(in));
				String record;
				//int lineCount = 0;// counter for each line, used to update line offset
				int value = (int) loc.getOffset();// offset of first line = offsets of this block
				String key;
				int bytecount = 0;//used to update size of each record
// loop for each record		
				while ((record = br.readLine()) != null) {
					//System.out.println("record " + record);
// keys are retrieved for each attrNum
					String cell[] = record.split(",");
					for (int indexCount = 0; indexCount < attrNums.size(); indexCount++) {
						if (attrNums.get(indexCount) < cell.length && !cell[attrNums.get(indexCount)].isEmpty()){ 
							key = cell[attrNums.get(indexCount)];
//add <key,val> into BTree
							strbTree.get(indexCount).add(key, value);
							//System.out.println("<key,val> for indexAttr "+attrNums.get(indexCount)+ " is " +key +"," + value );
						}
						//System.out.println("<key,val> for indexAttr "+attrNums.get(indexCount)+" is <"+ keys.get(indexCount) + "," + values+ ">");
					}
// record location is stored as value
					bytecount = record.getBytes().length;//size of each record
					value = value + bytecount + 1;
					//lineCount ++;
				}//end of record loop
				//System.out.println("lines " +lineCount);
				return strbTree;
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					if (in != null)
						in.close();
				} catch (Exception ex) {

				}
			}
		}
		return strbTree;
	}

	
	public ArrayList<BTree> setkeyvalue(String filePath, BlockLocation loc,
			ArrayList<Integer> attrNums)
			throws Exception {
		/*
		 * create index trees according to No. of indexAttr
		 * create keys for each indexAttr
		 */
		
		ArrayList<BTree> strbTree = new ArrayList<BTree>();
		
		for (int c = 0; c < attrNums.size(); c++) {
			strbTree.add(new BTree());
			//keys.add(new ArrayList<String>());
		}
		//ArrayList<String> keys = new ArrayList<String>(attrNums.size());
		//System.out.println(strbTree.size()+" trees are created");
		
		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));
		
		FileSystem fs = FileSystem.get(conf);
		Path path = new Path(fs.getWorkingDirectory() + filePath);
		
		if(!fs.exists(path)) {
			System.out.println("Error: Block at " +path+ " does not exist");
			//return 0;
		}
		else {
/**
 * reading whole block in buffer first
**/			
			FSDataInputStream fin = fs.open(path);
			byte[] buffer = new byte[(int) loc.getLength()];//block size
			fin.read(loc.getOffset(), buffer, 0, (int) loc.getLength());//access a block
/**
 * converting byte[] buffer into InputStream reading each line to get
 * key,val add key,val into index tree
**/
			InputStream in = null;
			BufferedReader br = null;
			try {
				in = new ByteArrayInputStream(buffer);
				br = new BufferedReader(new InputStreamReader(in));
				String record;
				//int value;
				int lineCount = 0;// counter for each line, used to update line offset
				int value = (int) loc.getOffset();// offset of first line = offsets of this block
				String key;
				int bytecount = 0;//used to update size of each record
// loop for each record		
				while ((record = br.readLine()) != null) {
					//System.out.println("record " + record);

					//values.add(lineCount == 0 ? offset : values.get(lineCount - 1) + bytecount + 1);
					//if (lineCount == 0) {
						//value = offset;
					//}
					//else {
						
					//}
					//System.out.println("\nLocation for Record " +lineCount+ " is " + values.get(lineCount));
// keys are retrieved for each attrNum
					String cell[] = record.split(",");
					for (int indexCount = 0; indexCount < attrNums.size(); indexCount++) {
						if (attrNums.get(indexCount) < cell.length && !cell[attrNums.get(indexCount)].isEmpty()){ 
							//keys.add(cell[attrNums.get(indexCount)]);
							key = cell[attrNums.get(indexCount)];
							strbTree.get(indexCount).add(key, value);
						}
						//System.out.println("<key,val> for indexAttr "+attrNums.get(indexCount)+" is <"+ keys.get(indexCount) + "," + values+ ">");
					}
// record location is stored as value
					bytecount = record.getBytes().length;//size of each record
					value = value + bytecount + 1;
					lineCount ++;
				}//end of record loop
				//System.out.println("lines " +lineCount);
				return strbTree;
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					if (in != null)
						in.close();
				} catch (Exception ex) {

				}
			}

		}
		conf.clear();
		return strbTree;
	}
	
//for adaptive index (each new index)
	public void setKeys(RandomAccessFile file, int index) throws Exception,
			NullPointerException {
		key = new ArrayList<String>();
		for (int j = 0; j < values.size(); j++) {
			file.seek(values.get(j));// set the pointer position
			String cell[] = file.readLine().split(",");
			key.add(cell[index]);
		}
	}

	public void printkeyval() {
		for (int j = 0; j < values.size(); j++) {
			System.out.println("Offest address of line " + j + ": "
					+ values.get(j));
			System.out.println("Attribute value: " + keys.get(j));
		}
	}

}
