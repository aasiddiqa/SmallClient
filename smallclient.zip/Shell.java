import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashSet;

import org.apache.commons.lang.time.StopWatch;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.BlockLocation;
import org.apache.hadoop.fs.ContentSummary;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.server.namenode.NameNode;


public class Shell {
	@SuppressWarnings("deprecation")
	public void runUpload(String[] src, String dest) throws Exception {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		String source = src[0].concat(src[1]);
		String destination = dest+src[1];

		BufferedReader br = new BufferedReader(new FileReader(source));

		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));

		FileSystem fs = FileSystem.get(conf);
//for Header file
		//System.out.println("Writing File Schema");
				
		FSDataOutputStream outSchema;
		Path hdrPath = new Path(fs.getWorkingDirectory() + dest + src[2]);
		
		outSchema = fs.create(hdrPath, true, 1000, (short) 1, fs.getDefaultBlockSize());
		BlockFile sch = new BlockFile();
		sch.upload(src[0] + src[2], outSchema, 1000);
//for data file
		Path dstPath = new Path(fs.getWorkingDirectory() + destination);

		if (fs.exists(dstPath)) {
			//System.out.println("File already exists | Overwriting");
		}
		FSDataOutputStream out;
		out = fs.create(dstPath, true);// overwrite = true

		BlockFile blk = new BlockFile();
		String record;
		// int blkLimit = (int) fs.getDefaultBlockSize();
		int blkLimit = (int) fs.getBlockSize(dstPath);
		Boolean hasCapacity = true;

		int blkNum = 0;
		while ((record = br.readLine()) != null) {
			if (hasCapacity) {
				hasCapacity = blk.addinBlockFile(src[0], record, blkLimit);
			} else {
				blkNum++;
				blk.upload(src[0], out, blkLimit, blkNum);
				blk.deleteBlockFile(src[0]);
				hasCapacity = blk.addinBlockFile(src[0], record, blkLimit);
			}
		}
		blkNum++;
		blk.upload(src[0], out, blkLimit, blkNum);
		blk.deleteBlockFile(src[0]);

		out.close();
		fs.close();
		br.close();
		stopWatch.suspend();
		System.out.println("|Success | Time taken " + stopWatch);

	}
	
	public void runIndex(String[] src, String[] indexAttrList, String fileDir)
			throws Exception {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		
		if (indexAttrList.length == 0) {
			System.out.println("indexAttributes are not provided");
			return;
		}
/**
 * get each indexAttr position and remove unmatched,
 * update indexing variables
**/
		ArrayList<Integer> attrNums;
		HeaderInfo header = new HeaderInfo();

		//System.out.println("Analyzing provided list of index attributes");
		header.analyzeIndexAttr(fileDir, src[1], src[2], indexAttrList);
		attrNums = header.tmpAttrNum;
		indexAttrList = header.indexAttrList;
		
		if (attrNums.size() == 0) {
			System.out.println("indexAttrList does not have valid attributes or already exist");
			return;
		}
		//System.out.println("|Success| Index List is updated");
		//System.out.println("Creating Index ... ");
/** create indexes if the attrList has something **/
		String fileName = fileDir.concat(src[1]);
/** required to access each block **/
		BlockInfo inf = new BlockInfo();
		BlockLocation[] locs = inf.getBlkLocations(fileName);
/** loop for each block **/
		int blkCount = 0;
		while (blkCount < locs.length) {
			//System.out.println("\nAccessing Block " + blkCount);
			ArrayList<BTree> strbTree = createIndex(fileName, locs[blkCount], attrNums);
			//System.out.println("|Success |" + strbTree.size() + " Indexes are created");
			//System.out.println("\nStoring Indexes ...");
/** loop for each index **/
			for (int indexCount = 0; indexCount < strbTree.size(); indexCount++) {
				String indexFile = fileDir + "indexes/" + indexAttrList[indexCount]+"/" + blkCount + ".ser";
				//System.out.println(indexFile);
				if(!storeIndex(indexFile, strbTree.get(indexCount), indexAttrList[indexCount])) {
					System.out.println("Problem storing indexes");
					return;
				}
				else {
					// System.out.println("Printing Indexes");
					
					//printIndex(indexLoc, indexAttrList[indexCount]);
					//System.out.println(" getting Metadata");
					//IndexMetadata Metadata = getMetadata(indexFile, indexAttrList[indexCount], inf.getBlkLocations(indexFile));
					String metaFile = fileDir + "metadata/" + indexAttrList[indexCount] + ".ser";
					IndexMetadata Metadata = getMetadata(indexFile, indexAttrList[indexCount], inf.getBlkLocations(indexFile), metaFile);
					if(!storeMetadata(Metadata, metaFile)) {
						System.out.println("Problem storing index metadata");
						return;
					}
					//Metadata.print(metaFile);
				}
			}//end of index loop
				blkCount++;
		}//end of block loop
		stopWatch.suspend();
		System.out.println("|Success | Time taken " + stopWatch);
		printIndexSize(fileDir + "metadata/", indexAttrList);
	}//end of runIndex method
	
	public void printIndexSize(String fileDir, String[] indexAttrList) throws IOException {
//loop for each index
		for (int indexCount = 0; indexCount < indexAttrList.length; indexCount++) {
			String metaFile = fileDir +  indexAttrList[indexCount] + ".ser";
			IndexMetadata meta = IndexMetadata.get(metaFile);
			System.out.println("Index Size for "+ indexAttrList[indexCount]+ ": " + meta.indexSize);
		}
	}
	public void runQuery(String queryString, String fileDir) throws Exception {
		String fileName = new String();
		ArrayList<String> selData = new ArrayList<String>();//columns to be retrieved
		ArrayList<Integer> selDataIndexes = new ArrayList<Integer>();//subscripts of selData
		ArrayList<String> attrNameList = new ArrayList<String>();//column to be used as selection predicate
		ArrayList<String> attrValueList = new ArrayList<String>();//value to be matched for searching
		ArrayList<String> multiAttrList = new ArrayList<String>();//query may have more than one selection predicates
		String metaStatus = new String();
				
		QueryParser parser = new QueryParser();
		String status = parser.analyze(queryString, fileDir); 
		if (!status.equals("null")) {
			fileName = parser.fileName;
			selData = parser.selData;//data to be fetched
			selDataIndexes = parser.dataIndexes;//subscripts of selData
			attrNameList = parser.attrName;//selection predicates
			if (status.equals("noIndex")) {
				System.out.println("Index(es) not found, run full scan query");
				metaStatus = "Miss";//index not available
				}
			else if (status.equals("hasIndex")){
				//System.out.println("|Success| Index(es) found");
				StopWatch stopWatch = new StopWatch();
				stopWatch.start();
				//System.out.println("|Success| Index(es) found");
				attrValueList = parser.attrValue;//selection criteria
				multiAttrList = parser.multiAttr;//if query has AND/OR
				metaStatus = "Hit";//index available
				BlockInfo inf = new BlockInfo();
				BlockLocation[] loc = inf.getBlkLocations(fileDir + fileName);
//loop for each block
				int blkCount =0;
				while(blkCount < loc.length) {
					//System.out.println("Accessing Block " +blkCount);
					//StopWatch stopwatch = new StopWatch();
					//stopwatch.start();
					ArrayList<Integer> location = searchRecord(fileDir,fileName, blkCount, attrNameList, attrValueList, multiAttrList);
					//stopwatch.suspend();
					//System.out.println("Record Searching Time " +stopwatch);
					if (!location.isEmpty()){
						//System.out.println("|Success| " + location.size() + " Record(s) found");
						fetchData(fileDir + fileName, loc[blkCount], location, selData, selDataIndexes);
					}
					blkCount ++;
				}//end of block loop		
				stopWatch.suspend();
				System.out.println("|Success | Time taken " + stopWatch);
			}
			QueryLog metadata = getMetadata(fileName, attrNameList, metaStatus);
			//System.out.println("QueryMetadata is \n" +metadata.toString());
			QueryLog log = new QueryLog();
			if(!log.update(metadata, fileDir + "log"))
				System.out.println("Log is not updated");
		}
		else
			System.out.println("Query discarded");
	}
	
	public void runPredictor(String[] inputFiles, String dstDir){
		Predictor pr = new Predictor();
		int numSlots = 10;//number of time slots
		ArrayList<ArrayList<String>> tSlots = new ArrayList<ArrayList<String>>();
		tSlots=Predictor.getSlots(numSlots, inputFiles, dstDir);//slots and queries in each slot
		
		String[] dAttr;
		dAttr = pr.getDAttr(inputFiles, dstDir);
		
		ArrayList<String> iAttr = new ArrayList<String>();//list to create new indexes
		ArrayList<String> rAttr = new ArrayList<String>();//list to remove indexes
		String decision;
		
		for (int d = 0; d < dAttr.length; d++){//each data Attribute
			decision = pr.decide(dAttr[d],numSlots,tSlots);
			if(decision != null||decision!="Sustain"){
				if(decision.equals("Create")){
					iAttr.add(dAttr[d]);
				}
				else if(decision.equals("Remove")){
					rAttr.add(dAttr[d]);
				}
			}
		}
		//create new indexes
		if (!iAttr.isEmpty()){
			String[] attrList = new String[iAttr.size()];
			iAttr.toArray(attrList);
			runIndex(inputFiles, attrList, dstDir);
		}
		//remove indexes
		if (!rAttr.isEmpty()){
			String[] attrList = new String[rAttr.size()];
			iAttr.toArray(attrList);
			remIndex(inputFiles, attrList, dstDir);
		}
		System.out.println("Success");
	}
	
	public static void remIndex(String[] src, String[] indexAttrList, String fileDir){
		
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public ArrayList<Integer> searchRecord(String fileDir, String fileName, int blkCount, ArrayList<String> indexName, ArrayList<String> val, ArrayList<String> multiAttr) throws IOException {
		//StopWatch stopwatch = new StopWatch();
		//stopwatch.start();
		//System.out.println("Searching Records ");
		String name[] = fileName.split("\\.");
		ArrayList<Integer> location = new ArrayList<Integer>();
		HashSet set = new HashSet();
		BTree index;
//loop for each index
		int indexCount = 0;
		while (indexCount <= multiAttr.size()) {
			index = IndexFile.get(fileDir + "indexes/" + indexName.get(indexCount)+"/" + blkCount + ".ser");//stored index is retrieved
			//index = IndexFile.get(fileDir + "indexes"+ name[0] +"/" + indexName.get(indexCount)+"/" + blkCount + ".ser");//stored index is retrieved
			//IndexFile idx = new IndexFile();
			//idx.print(fileDir + "indexes/" + indexName.get(indexCount)+"/" + blkCount + ".ser");
			//System.out.println("Searching " + val.get(indexCount));
			Object obj = index.search(val.get(indexCount));
			//System.out.println("Searching Records " + obj);
//if record list found
			if (obj != null){
				//System.out.println("Records found ");
				location = (ArrayList<Integer>) obj;//retrieved locations are converted from object to Integer
				if (indexCount == 0) {
					if(multiAttr.isEmpty()) {
						//stopwatch.suspend();
						//System.out.println("Record Searching Time " +stopwatch);
						return location;
					}
					set.addAll(location);
				}
//union/intersection of records according to multiAttr
				else {					
					if(multiAttr.get(indexCount -1).equals("AND"))
						set.retainAll(location);//intersection
					else
						set.addAll(location);//union
				}					
			}			
			//stopwatch.suspend();
			//System.out.println("Record Searching Time " +stopwatch);
			indexCount ++;
		}//end of index loop
		return new ArrayList<Integer>(set);
	}
	
	
	public void fetchData(String fileLoc, BlockLocation blkLoc, ArrayList<Integer> locations, ArrayList<String> selData, ArrayList<Integer> selDataIndexes) throws IOException {
		//StopWatch stopwatch = new StopWatch();
		//stopwatch.start();
		
		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));

		FileSystem fs = FileSystem.get(conf);

		Path path = new Path(fs.getWorkingDirectory() + fileLoc);
		
		//RandomAccessFile file = new RandomAccessFile("data/" + fileLoc, "r");
		FSDataInputStream file = fs.open(path);
		
		//System.out.println("\nRetrieved Data:");
		for (int j = 0; j< locations.size(); j++) {
//set the pointer position
			//file.seek( (blkLoc.getOffset()) + (long) locations.get(j));
			file.seek((long) locations.get(j));
			if (selDataIndexes.get(0) == -1) {
				if(file.readLine() != null){
				@SuppressWarnings("deprecation")
				String data=file.readLine();
				System.out.println(data);//print whole record
				}
			}
			else {
				@SuppressWarnings("deprecation")
				String a[] = file.readLine().split(",");
				for (int i = 0; i < selDataIndexes.size(); i ++) {
					//if (!a[selDataIndexes.get(i)].isEmpty())
					System.out.print(a[selDataIndexes.get(i)]+ " ");//print required specific attributes
					
				}
			}
		System.out.println();	
		}
		
		//stopwatch.suspend();

		//System.out.println("Record Retrieving Time " +stopwatch);
	}	
	
	public static QueryLog getMetadata(String fileName, ArrayList<String> attrName, String metaStatus) {
		
		String[] searchAttr = attrName.toArray(new String[attrName.size()]);
		String status = metaStatus;
		
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		Calendar calobj = Calendar.getInstance();
		String time = dateFormat.format(calobj.getTime());
		
		//QueryMetadata obj = new QueryMetadata(file, searchAttr, status, time);
		//System.out.println(obj.toString()+ " and " +searchAttr[0]);
		
		return(new QueryLog(searchAttr, status, time));
	}
	
	public void runIndexReplicas(String[] src, String[] indexAttrList, String fileDir)
			throws Exception {
		
		String fileName = fileDir.concat(src[1]);

		/*
		 * get each indexAttr position and remove unmatched,
		 * update indexing variables
		 */
		ArrayList<Integer> attrNums;
		HeaderInfo header = new HeaderInfo();

		System.out.println("Analyzing provided list of index attributes");
		//header.analyzeIndexAttr(fileDir, src[2], indexAttrList);
		attrNums = header.tmpAttrNum;
		indexAttrList = header.indexAttrList;

		System.out.println("AttrNum" + attrNums);
		System.out.println("indexAttrList" + Arrays.toString(indexAttrList));
		System.out.println("Success");
		
		BlockInfo inf = new BlockInfo();
		BlockLocation[] locs = inf.getBlkLocations(fileName);

		// loop for each block
		int blkCount = 0;
		while (blkCount < locs.length) {
			Configuration conf = new Configuration();
			conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
			conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
			conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));

			FileSystem fs = FileSystem.get(conf);

			Path path = new Path(fs.getWorkingDirectory() + fileName);
			
			//System.out.println("\nPath is " +path);
			System.out.println("\nAccessing Block " +blkCount);
			
			//get No. of indexes for each replica
			int nIndexes = (int) Math.ceil((double) attrNums.size()/ (int) fs.getReplication(path));
			//int nIndexes = (int) Math.ceil((double) attrNums.size()/ 3);
			System.out.println("\nnIndexes " +nIndexes);
	
			//loop for each replica
			int replica =0;
			while(replica < fs.getReplication(path)) {
				System.out.println("\nAccessing replica " +replica);
				
				//get indexAttr for each replica
				ArrayList<Integer> repAttrNums = new ArrayList<Integer>();
				ArrayList<String> repAttrList = new ArrayList<String>();
				int listOffset = replica * nIndexes;
				int i = listOffset;
				//System.out.println("listOffset " +listOffset+ " size is "+ attrNums.size());
				
				while (i < (listOffset + nIndexes) && i < attrNums.size()) {
					//System.out.println("loop ");
					repAttrNums.add(attrNums.get(i));
					repAttrList.add(indexAttrList[i]);
					i ++;
					//System.out.println("i is " +i);
				}
						
				//create indexes if the attrList has something
				if (repAttrNums.size() > 0) {
									
					System.out.println("Creating Index ... ");
					//ArrayList<BTree> strbTree = createIndex(path, locs[blkCount], repAttrNums, replica);
					ArrayList<BTree> strbTree = createIndex(fileName, locs[blkCount], attrNums);
					System.out.println("|Success |" + strbTree.size() + " Indexes are created");

					//for each index
					System.out.println("\nStoring Indexes ...");
				
					for (int indexCount =0; indexCount < strbTree.size(); indexCount++) {
						//System.out.println("\n");
						//BlockLocation[] idxlocs = storeIndex(fileDir+"indexes/"+repAttrList.get(indexCount)+src[1], strbTree.get(indexCount), locs[blkCount].getHosts()[replica]);
						//BlockLocation[] idxlocs = storeIndex(fileDir+"indexes/"+repAttrList.get(indexCount)+src[1], strbTree.get(indexCount));
						//System.out.println("Printing Indexes");
						//printIndex(fileDir, src[1], indexAttrList[indexCount]);
						//IndexMetadata Metadata =  getMetadata(fileDir, src[1], indexAttrList[indexCount], idxlocs, locs[blkCount]);
						//System.out.println(" getting Metadata");
						//if(storeMetadata(Metadata, fileDir, src[1]))
						//	System.out.println("|Success | Metadata is stored");
						//else
						//	System.out.println("Storing Metadata is unsuccessful");
						//System.out.println("Printing Metadata ...");
						//printMetadata(fileDir, src[1], indexAttrList[indexCount]);
					}
				}
				//keys = kv.keys;
				//values = kv.values;
								
				replica ++;
			}
			
			blkCount ++;
		}
	}
		
	
	public ArrayList<BTree> createIndex(String filePath, BlockLocation locs, ArrayList<Integer> attrNums) throws Exception {
		//get and add key-value pairs in each index tree
		KeyValue kv = new KeyValue();
		return kv.setkeyval(filePath, locs, attrNums);		
	}
	
	
	public Boolean storeIndex(String fileName, BTree index, String indexName)
			throws IOException, URISyntaxException {
		IndexFile file = new IndexFile();
		if(file.store(fileName, index, indexName)) {
			//System.out.println("|Success | Index is stored as " + fileName);
			return true;
		}
		return false;
	}
	
	public void printIndex(String fileDir, String fileName, String indexName) throws IOException {
		String filePath = fileDir + "indexes/"+indexName+ fileName;
		IndexFile data = new IndexFile();
		data.print(filePath);
	}
	
	public IndexMetadata getMetadata(String indexFile, String indexName, BlockLocation[] idxloc, String metaFile) throws Exception {
		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));

		FileSystem fs = FileSystem.get(conf);
		Path path = new Path (fs.getWorkingDirectory() + indexFile);
		
		//long offset = loc.getOffset();
		//long size = loc.getLength();
		
		FileSystem hdfs = path.getFileSystem(conf);
		//System.out.println("Path is "+path);
		//ContentSummary summary = hdfs.getContentSummary(path);
	    //long length = summary.getLength();
		FileStatus status = hdfs.getFileStatus(path);
		long length = status.getLen(); 
	    //System.out.println("Size calculated as " +length);    
	    DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		Calendar calobj = Calendar.getInstance();
		String created = dateFormat.format(calobj.getTime());
		String updated = null;
		
		return(new IndexMetadata(indexName, length, created, updated, metaFile));
	}
	
	
	public Boolean storeMetadata(IndexMetadata data, String fileName) throws IOException {
		return IndexMetadata.store(data, fileName);
	}
	
	public void printMetadata(String fileName) throws IOException {
		
		IndexMetadata meta = new IndexMetadata();
		meta.print(fileName);
	}
}
