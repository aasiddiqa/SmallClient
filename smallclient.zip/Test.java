import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.BlockLocation;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.server.namenode.BlockPlacementPolicy;
import org.apache.hadoop.hdfs.server.namenode.DatanodeDescriptor;
import org.apache.hadoop.io.IOUtils;

public abstract class Test extends BlockPlacementPolicy {

	public static void main(String args[]) throws IOException {

		String[] inputFiles = { "/home/ash/ashData/data/", "edges.csv",
				"schema_data.csv" }; // srcDirectory, FileName, FileSchema
		String[] indexAttr = { "statefp", "countyfp", "fullname" };
		// String[] indexAttr = {"statefp"};
		String dstDir = "/data/";// destDirectory

		String fileName = dstDir.concat(inputFiles[1]);

		Configuration conf = new Configuration();

		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));

		FileSystem fs = FileSystem.get(conf);

		Path path = new Path(fs.getWorkingDirectory() + "/data/");
		
		if (fs.exists(path)) {
			System.out.println("Dir found" + path);
		}
	}
	public void runInfo(String[] src, String[] indexAttrList, String fileDir) throws IOException {
		
		String fileName = fileDir.concat(src[1]);
		
		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));
		
		conf.set("dfs.datanode.address", "192.168.1.113:50010");

		FileSystem fs = FileSystem.get(conf);

		Path path = new Path(fs.getWorkingDirectory() + fileName);
		
		FileStatus status = fs.getFileStatus(path);

		BlockLocation[] locs  = fs.getFileBlockLocations(status, 0, status.getLen());
		
		System.out.println("Hosts " +Arrays.toString(locs[0].getHosts()));
		System.out.println("Names " +Arrays.toString(locs[0].getNames()));
		System.out.println("Number of blocks at slave2 are " +locs.length);
		
	}
}