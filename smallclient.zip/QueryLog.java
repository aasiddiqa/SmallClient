import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.DistributedFileSystem;


public class QueryLog {
	public String[] searchAttr;//stores selection attributes
	public String indexStatus;//stores Hit/Miss
	public String queryTime;
	
	public QueryLog() {
		
	}

	public QueryLog(String[] attrName, String status, String time){
		this.searchAttr = attrName;
		this.indexStatus = status;
		this.queryTime = time;
	}
	@Override
	public String toString() {
   	   	return new StringBuffer(" Search Attributes : ")
   	   	.append(Arrays.toString(this.searchAttr))
		.append("\n")
		.append(" Index Status : ")
		.append(this.indexStatus)
		.append("\n")
		.append(" Query Time : ")
		.append(this.queryTime)
		.append("\n").toString();
	}
	public Boolean update(QueryLog query, String file) throws IOException {
		String meta = Arrays.toString(query.searchAttr) +"\t"+ query.indexStatus +"\t"+ query.queryTime;
		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));

		FileSystem fs = FileSystem.get(conf);
		DistributedFileSystem hdfs = (DistributedFileSystem) fs;
		Path path = new Path(hdfs.getWorkingDirectory() + file);
		//System.out.println("path is " +path);
		FSDataOutputStream out;
		Boolean success = false;
		
		try{
			if (!hdfs.exists(path)) {
				out= hdfs.create(path, (short) 1);
			}
			else {
				out = hdfs.append(path);
				out.writeBytes("\n");
			}
			out.writeBytes(meta);
			success = true;
			out.close();
			hdfs.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return success;
	}
	
	public static void viewLog(String fileName) throws Exception {
		
		BufferedReader br = new BufferedReader(new FileReader(fileName));
		String queryMeta;
		while((queryMeta = br.readLine()) != null) {
			System.out.println(queryMeta);
		}
	}
}