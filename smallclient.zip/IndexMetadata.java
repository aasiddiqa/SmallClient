import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.Arrays;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.BlockLocation;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

//Index Metadata contains the information required to access an index created statically and to further
//utilize index for adaptive decisions

public class IndexMetadata implements Serializable{
	public String indexName;
//	public String path;
//	public String hostName;
//	public long blkOffset;
//	public long blkSize;
	public long indexSize;
	public String indexCreated;
	public String indexUpdated;

	public IndexMetadata(String name, long size, String created, String updated, String metaFile) throws IOException {
		//System.out.println("Size in method is  " +size);
		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));
		FileSystem fs = FileSystem.get(conf);
		Path path = new Path(fs.getWorkingDirectory() + metaFile);
		
		if(fs.exists(path)) {
			IndexMetadata fileData = get(metaFile);
			this.indexSize = size + fileData.indexSize;
			//System.out.println("Old Size is " +fileData.indexSize + " Added size is " +size + " Total is " + this.indexSize);
		}
		else 
			this.indexSize = size;
		this.indexName = name;
		this.indexCreated = created;
		this.indexUpdated = updated;
//		this.path = path;
//		this.hostName = loc[0].getNames()[0];
//		this.blkOffset = blkOffset;
//		this.blkSize = blkSize;
//		this.indexSize = size;
	}
	
	public IndexMetadata() {
	}
	
	public static Boolean store(IndexMetadata data, String filePath) throws IOException{
		
		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));

		FileSystem fs = FileSystem.get(conf);

		Path path = new Path(fs.getWorkingDirectory() + filePath);
		
		OutputStream out = fs.create(path, (short) 1);
		ObjectOutputStream obj = null;
		Boolean success = false;
		
		try
		{			
			obj = new ObjectOutputStream(out);
			obj.writeObject(data);
			obj.flush();
			
			success = true;
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally{
			try{
				if(obj != null) obj.close();
			} catch (Exception ex){
			}
		}
		return(success);
	}
	
	public static IndexMetadata get(String filePath) throws IOException {
		
		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));

		FileSystem fs = FileSystem.get(conf);

		Path path = new Path(fs.getWorkingDirectory() + filePath);
		
		if(!fs.exists(path)) {
			System.out.println("Metadata not found at " +path);
			//return;
		}
		
		FSDataInputStream in = null;
		ObjectInputStream obj = null;
		try {
			in = fs.open(path);
			obj = new ObjectInputStream(in);
			return (IndexMetadata) obj.readObject();
			//System.out.println("Retrieved Metadata is: \n"+data);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				if(obj != null) obj.close();
			} catch (Exception ex){
			}
		}
		return null;
	}
	
	public void print(String filePath) throws IOException{
		
		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));

		FileSystem fs = FileSystem.get(conf);

		Path path = new Path(fs.getWorkingDirectory() + filePath);
		
		if(!fs.exists(path)) {
			System.out.println("Metadata not found at " +path);
			return;
		}
		
		FSDataInputStream in = null;
		ObjectInputStream obj = null;
		try {
			in = fs.open(path);
			obj = new ObjectInputStream(in);
			IndexMetadata data = (IndexMetadata) obj.readObject();
			System.out.println("Retrieved Metadata is: \n"+data);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				if(obj != null) obj.close();
			} catch (Exception ex){
			}
		}
	}

	@Override
	public String toString() {
		return new StringBuffer(" Index Name : ")
		.append(this.indexName)
//		.append("\n")
//		.append(" Index Block Host : ")
//		.append(this.hostName)
		.append("\n")
		.append(" Index Size : ")
		.append(this.indexSize)
//		.append("\n")
//		.append(" Index Path : ")
//		.append(this.path)
		.append("\n")
		.append(" Index Created : ")
		.append(this.indexCreated)
		.append("\n")
		.append(" Index Updated : ")
		.append(this.indexUpdated).append("\n").toString();
	}
}