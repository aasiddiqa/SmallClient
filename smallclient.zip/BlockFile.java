import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;

import org.apache.hadoop.fs.FSDataOutputStream;


public class BlockFile {
	public void upload(String source, FSDataOutputStream out, int blkLimit) throws IOException {
		//System.out.println("\nWritng Schema ");
				
	//	String source = src + "tempblk.txt";
		
		InputStream in = new BufferedInputStream(new FileInputStream(
				new File(source)));

		byte[] buffer = new byte[blkLimit];
		@SuppressWarnings("unused")
		int read = in.read(buffer);
		
		out.write(buffer, 0, blkLimit);

		//System.out.println("Schema successfully uploaded");
		
		// Close all the file descriptors
		in.close();
		
	}
	
	public void upload(String src, FSDataOutputStream out, int blkLimit,
			int blkNum) throws IOException {
		//System.out.println("\nWritng block " + blkNum);
				
		String source = src + "tempblk.txt";
		
		InputStream in = new BufferedInputStream(new FileInputStream(
				new File(source)));

		byte[] buffer = new byte[blkLimit];
		@SuppressWarnings("unused")
		int read = in.read(buffer);
		
		out.write(buffer, 0, blkLimit);

		//System.out.println("Successfully uploaded");
		
		// Close all the file descriptors
		in.close();
		
	}
	
	public Boolean addinBlockFile(String dir, String line, int blkLimit) throws Exception {
		String fileName = dir + "tempblk.txt";
		File file = new File(fileName);
		BufferedWriter bw;
		if(!file.exists()) {
			file.createNewFile();
			bw = new BufferedWriter(new FileWriter(fileName));
		}
		else {
			bw = new BufferedWriter(new FileWriter(fileName, true));
			bw.newLine();
		}
			long size = file.length() + line.length();
			if(size < blkLimit){
				bw.write(line);
				bw.close();
				return true;
			}
		else {
			bw.close();
			return false;
		}
	}
	
	public void deleteBlockFile(String src) {
		String tmpFile = src + "tempblk.txt";
		File file = new File(tmpFile);
		Boolean success = file.delete();
		if (!success) {
			System.out.println("Error | Unable to delete temporary block file");
			return;
		}
	}
}
