import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;

import org.apache.commons.lang.time.StopWatch;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.BlockLocation;
import org.apache.hadoop.fs.ContentSummary;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

public class shell2 {
	public void runQuery(String queryString, String fileDir) throws Exception {
		String fileName = new String();
		ArrayList<String> selData = new ArrayList<String>();//columns to be retrieved
		ArrayList<Integer> selDataIndexes = new ArrayList<Integer>();//subscripts of selData
		ArrayList<String> attrName = new ArrayList<String>();//column to be used as selection predicate
		ArrayList<String> attrValue = new ArrayList<String>();//value to be matched for searching
		ArrayList<String> multiAttr = new ArrayList<String>();//query may have more than one selection predicates
		String metaStatus = new String();
				
		QueryParser parser = new QueryParser();
		String status = parser.analyze(queryString, fileDir); 
		if (!status.equals("null")) {
			fileName = parser.fileName;
			selData = parser.selData;//data to be fetched
			selDataIndexes = parser.dataIndexes;//subscripts of selData
			attrName = parser.attrName;//selection predicates
			if (status.equals("noIndex")) {
				System.out.println("Index(es) not found, run full scan quey");
				metaStatus = "Miss";//index not available
				}
			else if (status.equals("hasIndex")){
				System.out.println("|Success| Index(es) found");
				attrValue = parser.attrValue;//selection criteria
				multiAttr = parser.multiAttr;//if query has AND/OR
				metaStatus = "Hit";//index available
				
				ArrayList<Integer> location = searchRecord(fileDir, fileName, attrName, attrValue, multiAttr);
				if (location.isEmpty()){
					System.out.println("Record not found");
					return;
				}
				else {
					System.out.println("|Success| Record(s) found");
					fetchData(fileDir + fileName, location, selData, selDataIndexes);
				}
			}
			QueryLog metadata = getMetadata(fileName, attrName, metaStatus);
			//System.out.println("QueryMetadata is " +metadata.toString());
			QueryLog log = updateLog(metadata, fileDir, fileName);
		}
		else
			System.out.println("Query discarded");
	}
	
	public static QueryLog updateLog(QueryLog metadata, String fileDir, String fileName) throws IOException {
		QueryLog log = new QueryLog();
		Boolean success = log.update(metadata, fileDir + "log/" +fileName);
		if(success)
			System.out.println("Query Log is updated");
		return(log);
	}
	
	public static QueryLog getMetadata(String fileName, ArrayList<String> attrName, String metaStatus) {
		
		String[] searchAttr = attrName.toArray(new String[attrName.size()]);
		String status = metaStatus;
		
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		Calendar calobj = Calendar.getInstance();
		String time = dateFormat.format(calobj.getTime());
		
		//QueryMetadata obj = new QueryMetadata(file, searchAttr, status, time);
		//System.out.println(obj.toString()+ " and " +searchAttr[0]);
		
		return(new QueryLog(searchAttr, status, time));
	}
	
public void fetchData(String fileLoc, ArrayList<Integer> location, ArrayList<String> selData, ArrayList<Integer> selDataIndexes) throws IOException {
	StopWatch stopwatch = new StopWatch();
	stopwatch.start();
	
	Configuration conf = new Configuration();
	conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
	conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
	conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));

	FileSystem fs = FileSystem.get(conf);

	Path path = new Path(fs.getWorkingDirectory() + fileLoc);
	
	//RandomAccessFile file = new RandomAccessFile("data/" + fileLoc, "r");
	FSDataInputStream file = fs.open(path);
	
	System.out.println("\nRetrieved Data:");
	for (int j = 0; j< location.size(); j++) {
		file.seek(location.get(j));//set the pointer position
		if (selDataIndexes.get(0) == -1) {
			String data=file.readLine();
			System.out.println(data);//print whole record
		}
		else {
			String a[] = file.readLine().split(",");
			for (int i =0; i < selData.size(); i ++) {
				System.out.print(a[i]+ " ");//print required specific attributes
			}
		}
	System.out.println();	
	}
	
	stopwatch.suspend();

	System.out.println("Record Retrieving Time " +stopwatch);
}	
	public ArrayList<Integer> searchRecord(String fileDir, String fileName, ArrayList<String> indexName, ArrayList<String> val, ArrayList<String> multiAttr) throws IOException {
		StopWatch stopwatch = new StopWatch();
		stopwatch.start();
		
		ArrayList<Integer> location = new ArrayList<Integer>();
		BTree index = IndexFile.get(fileDir + "indexes/" + indexName.get(0) +"/0.ser");//stored index is retrieved
		//System.out.println("Retrieved Index is: \n"+index.toString());
		//System.out.println("<key,val> to search are <" +indexName.get(0)+ "," + val.get(0)+ ">");
		
		Object obj = index.search(val.get(0));
		if (obj != null){
			//System.out.println("obj is " + obj.toString());
			location = (ArrayList<Integer>) index.search(val.get(0));//retrieved locations are converted from object to Integer
		}
		if(multiAttr.isEmpty()) {
			stopwatch.suspend();
			System.out.println("Record Searching Time " +stopwatch);
			
			return(location);
		}
		else {
			HashSet set = new HashSet();
			set.addAll(location);
			ArrayList<Integer> location1 = new ArrayList<Integer>();
			int i =1;
			while (i <= multiAttr.size()) {
				index = IndexFile.get(fileDir + "indexes/" + indexName.get(0) + fileName);
				location1 = (ArrayList<Integer>) index.search(val.get(i));//retrieved locations are converted from object to Integer
				if(multiAttr.get(i -1).equals("AND")) {
					set.retainAll(location1);
				}
				else
					set.addAll(location1);
				i ++;
			}
			stopwatch.suspend();
			System.out.println("Record Searching Time " +stopwatch);
			
			return(new ArrayList<Integer>(set));
		}
	}
		
	
	
	public void printIndex(String fileDir, String fileName, String indexName) throws IOException {
		String filePath = fileDir + "indexes/"+indexName+ fileName;
		IndexFile data = new IndexFile();
		data.print(filePath);
	}
	
	
	
	public Boolean storeMetadata(IndexMetadata data, String fileDir, String fileName) throws IOException {
		String filePath = fileDir + "metadata/" + data.indexName+ fileName;
		return IndexMetadata.store(data, filePath);
	}
	
	public void printMetadata(String fileDir, String fileName, String indexName) throws IOException {
		String filePath = fileDir + "metadata/" + indexName+ fileName;
		IndexMetadata meta = new IndexMetadata();
		meta.print(filePath);
	}
	
	public void getthisURI(String[] src, String dest) throws IOException {
		String source = src[0].concat(src[1]);
		String destination = dest.concat(src[1]);

		BufferedReader br = new BufferedReader(new FileReader(source));

		Configuration conf = new Configuration();
		conf.addResource(new Path("/usr/local/hadoop/conf/core-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/hdfs-site.xml"));
		conf.addResource(new Path("/usr/local/hadoop/conf/mapred-site.xml"));

		FileSystem fs = FileSystem.get(conf);
		System.out.println("\nURI " + fs.getUri());
		System.out.println("\nWorking Directory " + fs.getWorkingDirectory());
	}
}
